criaCartao(
    'Primeira pergunta',
    'Quem eu sou?',
    'Eu sou a isa, tenho 16 anos, gosto de jogar volêi e sou cristã'
)

criaCartao(
    'Segunda pergunta',
    'Minha família é?',
    'Complicada, mas amorosa'
)

criaCartao(
    'Terceira pergunta',
    'Onde moro?',
    'Moro em Pinhão-PR, no bairro Vila Caldas, longitude -25.707320, latitude -51.645064 '
)

criaCartao(
    'Quarta pergunta',
    'Onde estudo?',
    'No colégio estadual Mario Evaldo Morski, 1979 foi fundado'
) 

criaCartao(
    'Quinta pergunta',
    'Minha turma',
    'É cheia de alunos inteligentes e muitos também desinteressados'
)

criaCartao(
    'sexta pergunta',
    'Faculdade?',
    'Não sei mais qual quero fazer'
) 
criaCartao(
    ' setima pergunta',
    'Minha cidade?',
    'É pequena mais eu gosto'
) 

criaCartao(
    ' setima pergunta',
    'Meu sonho?',
    'Sonho em ter uma casa confortável, e um trabalho bom'
) 


